import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { default as pnp, ItemAddResult,Web } from "sp-pnp-js";
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneLabel,
  PropertyPaneToggle,
  PropertyPaneDropdown,
  PropertyPaneCheckbox,
  PropertyPaneLink,
  PropertyPaneSlider,
  IPropertyPaneDropdownOption
} from '@microsoft/sp-webpart-base';

import * as strings from 'AllBannersWebPartStrings';
import AllBanners from './components/AllBanners';
import { IAllBannersProps } from './components/IAllBannersProps';

export interface IAllBannersWebPartProps {
  description: string;
  bannerList: string;
  bannerHorizonatalSpace: string;
  bannerVerticalSpace:string;
  bannerPosition:string;
  allbanners:any;
  bannerfontSize:string;
}

export default class AllBannersWebPart extends BaseClientSideWebPart<IAllBannersWebPartProps> {
  private listDropdownDisabled: boolean = true;
  private Banners: IPropertyPaneDropdownOption[];
  public render(): void {
    this.getBannerItems().then(bannerItems =>{
      const element: React.ReactElement<IAllBannersProps > = React.createElement(
        AllBanners,
        {
          Context:this.context,
          BannerListName:this.properties.bannerList,
          BannerPosition:this.properties.bannerPosition,
          BannerHorizonatalSpace:this.properties.bannerHorizonatalSpace,
          BannerVerticalSpace:this.properties.bannerVerticalSpace,
          BannerItems:bannerItems,
          BannerFontSize:this.properties.bannerfontSize
        }
      );

      ReactDom.render(element, this.domElement);
    });
  }
  public getBannerItems() : Promise<any[]> {
    let pnpweb = new Web(this.context.pageContext.web.absoluteUrl);
    return new Promise<any[]>((resolve, reject) => {
          pnpweb.lists.getByTitle(this.properties.bannerList).items.getAll().then((allItems:any[]) => {
             resolve(allItems);
        });
    });
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  protected onPropertyPaneConfigurationStart(): void {
    this.listDropdownDisabled = !this.Banners;
    if (this.Banners) {
       return;
     }
    this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'bannerList');
    this.getAllLists().then((listNames: any[]): void => {
        var sitelists = listNames.map((type)=> {
          return { text: type.Title, key: type.Title };
       });
        this.Banners = sitelists;
        this.listDropdownDisabled = false;
        this.context.propertyPane.refresh();
        this.context.statusRenderer.clearLoadingIndicator(this.domElement);
        this.render();
      });
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: "Please use below configuration to display Banners"
          },
          groups: [
            {
              groupFields: [
                PropertyPaneDropdown('bannerList', {
                  label:'Select List',
                  options: this.Banners,
                  disabled: this.listDropdownDisabled
                }),
                PropertyPaneTextField('bannerHorizonatalSpace', {
                  label: "Banner Horizontal Space in Px"
                }),
                PropertyPaneTextField('bannerVerticalSpace', {
                  label: "Banner Vertical Space in Px"
                }),
                PropertyPaneDropdown('bannerPosition', {
                  label:'Banners Position',
                  options: [
                    { key: 'Vertical', text: 'Vertical' },
                    { key: 'Horizontal', text: 'Horizontal' }
                  ]
                }),
                PropertyPaneTextField('bannerfontSize', {
                  label: "Banner Text Font in Px"
                })            
              ]
            }
          ]
        }
      ]
    };
  }

  public getAllLists():Promise<any[]>{
    let pnpweb = new Web(this.context.pageContext.web.absoluteUrl);
    return new Promise<any[]>((resolve, reject) => {
          pnpweb.lists.filter("Hidden eq false").get().then((allLists:any[]) => {
          resolve(allLists);
        });
    });
  }
}
