declare interface IAllBannersWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AllBannersWebPartStrings' {
  const strings: IAllBannersWebPartStrings;
  export = strings;
}
