import * as React from 'react';
import styles from './AllBanners.module.scss';
import { IAllBannersProps } from './IAllBannersProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { default as pnp, ItemAddResult,Web } from "sp-pnp-js";

export interface BannerProperties{
  AllBanner : any[];
  hover :boolean;
}
export default class AllBanners extends React.Component<IAllBannersProps,BannerProperties> {
  constructor(props) {    
    super(props);
    this.state = {
      AllBanner : [],
      hover:false
    };
    this.bannerEnter = this.bannerEnter.bind(this);
    this.bannerLeave = this.bannerLeave.bind(this);
  }
    public render(): React.ReactElement<IAllBannersProps> {
      let mapeedBanners = this.props.BannerItems.map(banner=>{
        return {banner} ;
      });
      return (
        <form> 
           {mapeedBanners.map((banner,key)=>{
              return(<a style={{textDecoration:'none',color:'white',fontSize:this.props.BannerFontSize+'px'}} href={escape(banner.banner.RedirectionURL.Url)} target={banner.banner.OpenIn=='Same'?'_self':'_blank'}>
                <div id={banner.banner.Title+'Banner'} onMouseEnter={this.bannerEnter} onMouseLeave={this.bannerLeave} className={`${styles.bannerHorizontal}`} style={{marginBottom:this.props.BannerVerticalSpace +'px',backgroundColor: escape(this.state.hover? banner.banner.HoverColor :banner.banner.BackGroundColor),textAlign:'center',height:'40px'}}> 
                 {(banner.banner.Title)}</div> </a>);
           })}
        </form>
      );
  }
  private bannerEnter() : void{
    this.setState({ hover: true });
  }
  private bannerLeave() : void{
    this.setState({ hover: false });
  }
}

