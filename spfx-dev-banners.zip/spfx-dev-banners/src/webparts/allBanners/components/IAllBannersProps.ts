import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IAllBannersProps {
  Context : WebPartContext;
  BannerListName : string;
  BannerPosition: string;
  BannerHorizonatalSpace : string;
  BannerVerticalSpace:string;
  BannerItems : any;
  BannerFontSize:string;
}
