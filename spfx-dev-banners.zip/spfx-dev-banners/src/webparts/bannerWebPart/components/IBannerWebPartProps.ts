import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IBannerWebPartProps {
   BannerItems:any;
   context :WebPartContext;
   BannerColor : string;
   BannerTitle : string;
   BannerPosition: string;
   BannerURL : string;
}
