import * as React from 'react';
import styles from './BannerWebPart.module.scss';
import { IBannerWebPartProps } from './IBannerWebPartProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class BannerWebPart extends React.Component<IBannerWebPartProps, {}> {
  public render(): React.ReactElement<IBannerWebPartProps> {
    return (
     <div className={styles.banneritem}  style={{ backgroundColor: escape(this.props.BannerColor) }}> 
          <a className={styles.bannerlink} href={escape(this.props.BannerURL)} target="_blank">{(this.props.BannerTitle)}</a>
     </div>
    );
  }
}
