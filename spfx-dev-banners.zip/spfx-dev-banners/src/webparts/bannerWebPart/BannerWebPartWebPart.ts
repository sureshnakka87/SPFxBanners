import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { default as pnp, ItemAddResult,Web } from "sp-pnp-js";
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneLabel,
  PropertyPaneToggle,
  PropertyPaneDropdown,
  PropertyPaneCheckbox,
  PropertyPaneLink,
  PropertyPaneSlider,
  IPropertyPaneDropdownOption
} from '@microsoft/sp-webpart-base';

import * as strings from 'BannerWebPartWebPartStrings';
import BannerWebPart from './components/BannerWebPart';
import { IBannerWebPartProps } from './components/IBannerWebPartProps';

export interface IBannerWebPartWebPartProps {
  bannercolor:string;
  bannerTitle : string;
  bannerPosition:string;
  bannerURL :string;
}

export default class BannerWebPartWebPart extends BaseClientSideWebPart<IBannerWebPartWebPartProps> {
  private itemsDropdownDisabled: boolean = true;
  private items: IPropertyPaneDropdownOption[];
  public render(): void {
    this.getBannerItemValues().then(items=>{
    const element: React.ReactElement<IBannerWebPartProps > = React.createElement(
      BannerWebPart,
      {
        BannerItems:items,
        context : this.context,
        BannerColor: this.properties.bannercolor,
        BannerTitle:this.properties.bannerTitle,
        BannerPosition : this.properties.bannerPosition,
        BannerURL : this.properties.bannerURL
      }
    );
    ReactDom.render(element, this.domElement);
  });
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  protected onPropertyPaneConfigurationStart(): void {
    this.itemsDropdownDisabled = !this.items;

    if (this.items) {
      return;
    }

    this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'lists');

    this.loadLists()
      .then((listOptions: any[]): void => {
        var siteTypes = listOptions.map((type)=> {
          return { text: type.Title, key: type.Color };
       });
        this.items = siteTypes;
        this.itemsDropdownDisabled = false;
        this.context.propertyPane.refresh();
        this.context.statusRenderer.clearLoadingIndicator(this.domElement);
        this.render();
      });
  }
  private loadLists(): Promise<any[]> {
      let pnpweb = new Web(this.context.pageContext.web.absoluteUrl);
      return new Promise<any[]>((resolve, reject) => {
        pnpweb.lists.getByTitle("Banner Colors").items.select("Title,Color").getAll().then((allItems:any[]) => {
        resolve(allItems);
      });
    });
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
      groups: [
            {
              groupFields: [
                PropertyPaneTextField('bannerTitle', {
                  label: "Banner Title"
                }),
                PropertyPaneTextField('bannerURL', {
                  label: "Banner URL"
                }),
                PropertyPaneDropdown('bannercolor', {
                  label:'Select Banner Color',
                  options: this.items,
                  disabled: this.itemsDropdownDisabled
                }),
                PropertyPaneDropdown('bannerPosition', {
                  label:'Banner Style',
                  options: [
                    { key: 'Item1', text: 'Middle' },
                    { key: 'Item2', text: 'Left' },
                    { key: 'Item3', text: 'Right' }
                  ]
                })
              ]
            }
          ]
        }
      ]
    };
  }
  public getBannerItemValues():Promise<any[]>{
    let pnpweb = new Web(this.context.pageContext.web.absoluteUrl);
    return new Promise<any[]>((resolve, reject) => {
          pnpweb.lists.getByTitle("Banner Colors").items.select("Title,Color").getAll().then((allItems:any[]) => {
          resolve(allItems);
        });
    });
  }
}
