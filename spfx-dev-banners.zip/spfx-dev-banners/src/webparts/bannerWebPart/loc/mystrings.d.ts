declare interface IBannerWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BannerWebPartWebPartStrings' {
  const strings: IBannerWebPartWebPartStrings;
  export = strings;
}
